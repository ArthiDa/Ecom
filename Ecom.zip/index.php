<?php include('MenuXFooter/main.php') ?>
<?php
    $sql2 = "SELECT * FROM catagory";
    $res2 = mysqli_query($conn,$sql2);
    $count2 = mysqli_num_rows($res2);

?>
    <!-- ***** Main Banner Area Start ***** -->
    <div class="main-banner" id="top">
    <?php
        if(isset($_SESSION['order'])){
            ?>
            <div class="text-center py-2 text-success">
                <h3><?php echo $_SESSION['order']?></h3>
            </div>
            <?php
            unset($_SESSION['order']);
        }
    ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="left-content">
                        <div class="thumb">
                            <div class="inner-content">
                                <h4>We Are Hexashop</h4>
                                <span>Awesome, clean &amp; creative php5 Template</span>
                                <div class="main-border-button">
                                    <li class="scroll-to-section"><a href="#men">Purchase Now!</a></li>
                                </div>
                            </div>
                            <img src="img/leftbanner.jpg" alt="">
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-6">
                    <div class="right-content">
                        <div class="row">
                        <?php
                        if($count2>0){
                            while($row2=mysqli_fetch_assoc($res2)){
                                $id = $row2["catagoryID"];
                                $name = $row2["Name"];
                                $img = $row2["ImgName"];
                                $banner = $row2["ImgBanner"];
                                $qt = $row2["Quotes"];
                                ?>

                            <div class="col-lg-6">
                                <div class="right-first-image">
                                    <div class="thumb">
                                        <div class="inner-content">
                                            <h4><?php echo $name;?></h4>
                                            <span>Best <?php echo $name;?> for you</span>
                                        </div>
                                        <div class="hover-content">
                                            <div class="inner">
                                                <h4><?php echo $name;?></h4>
                                                <p><?php echo $qt;?></p>
                                                <div class="main-border-button">
                                                    <a href="<?php echo SITEURL;?>products.php?catagory_id=<?php echo $id?>">Discover More</a>
                                                </div>
                                            </div>
                                        </div>
                                        <img src="<?php echo SITEURL;?>img/<?php echo $img;?>">
                                    </div>
                                </div>
                            </div>
                            <?php
                            }
                        }
                        ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->

    <!-- ***** Popular Products Area start ***** -->
    <?php
    $topSql = "SELECT * from orders";
    $topRes = mysqli_query($conn,$topSql);
    $topProduct = [];
    $cnt = mysqli_num_rows($topRes);
    while($cnt && $topRow=mysqli_fetch_assoc($topRes)){
    $pID = $topRow['productID'];
    $pCN = $topRow['Quantity'];
    if(array_key_exists($pID,$topProduct)){
        $topProduct[$pID] = $topProduct[$pID] + $pCN;
    }
    else $topProduct[$pID] = $pCN;
    }
    arsort($topProduct);
    ?>
    <section class="section" id="men">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-heading">
                        <h2>Popular Products</h2>
                        <span>Products makes Hexashop different from other.</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="men-item-carousel">
                        <div class="owl-men-item owl-carousel">
                            <?php
                                if($cnt){
                                    $counter = 0;
                                    foreach($topProduct as $PID => $value){
                                        $sql = "SELECT * from product where productID = $PID";
                                        $res = mysqli_query($conn,$sql);
                                        $row=mysqli_fetch_assoc($res);
                                        $id = $row["productID"];
                                        $imgName = $row["ImgName"];
                                        $pTitle = $row["Title"];
                                        $pDes = $row["Des"];
                                        $price = $row["Price"];
                                        $st = $row["Status"];
                                        if($st==1){
                                            $status = "<span class='alert alert-success text-center' role='alert'>In Stock</span>";
                                        }
                                        else{
                                            $status = "<span class='alert alert-danger text-center' role='alert'>Out Stock</span>";
                                        }
                                        ?>

                                        <div class="item">
                                            <div class="thumb">
                                                <div class="hover-content">
                                                    <ul>
                                                        <li><a href="<?php echo SITEURL; ?>single-product.php?product_id=<?php echo $id;?> "><i class="fa fa-eye"></i></a></li>
                                                        <li onclick="addItem('<?php echo $id?>','<?php echo $pTitle?>','<?php echo $imgName?>','<?php echo $price?>')"><a><i class="fa fa-shopping-cart" ></i></a></li>
                                                    </ul>
                                                </div>
                                                <img src="<?php echo SITEURL; ?>img/<?php echo $imgName;?>" height="300px" alt="">
                                            </div>
                                            <div class="down-content">
                                                <h4><?php echo $pTitle;?></h4>
                                                <span>$<?php echo $price;?></span>
                                                <?php echo $status;?>
                                                
                                            </div>
                                        </div>
                                        
                                        <?php
                                        $counter++;
                                        if($counter==3){
                                            break;
                                        }
                                    }
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Men Area Ends ***** -->

    <section>
        <div class="container">
            <h1 class=" text-center pb-5 text-uppercase">Developers</h1>
            <div class="row justify-content-center align-items-center ">
                <div class="col-md-4">
                <div class="fcard">
            <div class="ftop">
                <img src="https://avatars.githubusercontent.com/u/58880826?v=4" alt="">
            </div>
            <div class="fover">
                AYAT
            </div>

        </div>
                </div>

                <div class="col-md-4">
                <div class="fcard">
            <div class="ftop">
                <img src="https://avatars.githubusercontent.com/u/84791022?v=4" alt="">
            </div>
            <div class="fover">
                Turjo
            </div>

        </div>
                </div>

                <div class="col-md-4">
                <div class="fcard">
            <div class="ftop">
                <img src="https://avatars.githubusercontent.com/u/90525298?v=4" alt="">
            </div>
            <div class="fover">
                Arthi
            </div>

        </div>
                </div>
            </div>
            
        </div>
    </section>

    <!-- jQuery -->
    <script src="assets/js/jquery-2.1.0.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins -->
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/accordions.js"></script>
    <script src="assets/js/datepicker.js"></script>
    <script src="assets/js/scrollreveal.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/imgfix.min.js"></script> 
    <script src="assets/js/slick.js"></script> 
    <script src="assets/js/lightbox.js"></script> 
    <script src="assets/js/isotope.js"></script> 
    
    <!-- Global Init -->
    <script src="assets/js/custom.js"></script>

    <script>

        $(function() {
            var selectedClass = "";
            $("p").click(function(){
            selectedClass = $(this).attr("data-rel");
            $("#portfolio").fadeTo(50, 0.1);
                $("#portfolio div").not("."+selectedClass).fadeOut();
            setTimeout(function() {
              $("."+selectedClass).fadeIn();
              $("#portfolio").fadeTo(50, 1);
            }, 500);
                
            });
        });

    </script>
    <link rel="stylesheet" href="prof.css">
    <?php include('MenuXFooter/footer.php') ?>

  </body>
    </html>